--TABLAS--
CREATE TABLE Participante(
    tid VARCHAR(3) NOT NULL,
    nid VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    pais VARCHAR(30) NOT NULL,
    fRegistro DATE NOT NULL,
    fRetiro DATE,
    PRIMARY KEY(tid,nid)
);

CREATE TABLE Atleta(
    tID VARCHAR(3) NOT NULL,
    nID VARCHAR(15) NOT NULL,
    tIDAtleta VARCHAR(3) NOT NULL,
    nIDAtleta VARCHAR(15) NOT NULL,
    rh VARCHAR(3) NOT NULL,
    tSangre VARCHAR(2)NOT NULL,
    PRIMARY KEY(tidAtleta,nidAtleta)
);

CREATE TABLE Entrenador(
    tIDEntrenador VARCHAR(3) NOT NULL,
    nIDEntrenador VARCHAR(15) NOT NULL,
    seguro VARCHAR(3) NOT NULL,
    PRIMARY KEY(nidEntrenador,tidEntrenador)
    );

CREATE TABLE Evaluacion(
    numero INTEGER NOT NULL,
    fecha DATE NOT NULL,
    puntaje INTEGER,
    PRIMARY KEY(numero)
);
CREATE TABLE Registro(
    numero NUMBER(8) NOT NULL,
    fecha DATE NOT NULL,
    hora NUMBER(4),
    sensor VARCHAR(1) NOT NULL,
    valor NUMBER(8) NOT NULL
);

CREATE TABLE Actividad(
    numero NUMBER(8) NOT NULL,
    fechainicio DATE NOT NULL,
    horainicio NUMBER(4) NOT NULL,
    tiempoToal NUMBER(4) NOT NULL,
    pulsacionesProm NUMBER NOT NULL
);

CREATE TABLE EntrenadoPor(
    tIDAtleta VARCHAR(3) NOT NULL,
    nIDAtleta VARCHAR(15) NOT NULL,
    tIDEntrenador VARCHAR(3) NOT NULL,
    nIDEntrenador VARCHAR(15) NOT NULL
);

CREATE TABLE Sesion(
    dia NUMBER(1) NOT NULL,
    orden INTEGER NOT NULL,
    duracion INTEGER NOT NULL,
    descripcion VARCHAR(100) NOT NULL
);

CREATE TABLE SimilarA(
    porcentaje INTEGER,
    numero INTEGER NOT NULL
);

CREATE TABLE ContactoDe(
    tID VARCHAR(3) NOT NULL,
    nID VARCHAR(15) NOT NULL,
    tIDAtleta VARCHAR(3) NOT NULL,
    nIDAtleta VARCHAR(15) NOT NULL
);

CREATE TABLE libre(
    libreID VARCHAR NOT NULL,
    IDAtleta VARCHAR(3) NOT NULL,
    numero NUMBER(8) NOT NULL
);

CREATE TABLE planeada(
    planeadaID NUMBER(3) NOT NULL,
    nombre VARCHAR NOT NULL,
    tipo VARCHAR NOT NULL,
    fechaCreacion DATE NOT NULL,
    entrenador VARCHAR NOT NULL,
    atleta VARCHAR NOT NULL
);
--Restricciones declarativas--
    |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |